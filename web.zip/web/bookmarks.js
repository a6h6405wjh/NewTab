﻿'use strict';

// Namespace.
var ntp = ntp ||
    {
        ignore: false,
        parentId: "1",
        id: "1"
    };

ntp.nodeToHtml = function(node)
{
    var div = document.createElement("div");
    var anchor = document.createElement("a");
    var label = document.createElement("span");
    var img = document.createElement("img");
    var title;

    div.classList += "book";
    title = node.title;
    div.id = node.id;

    // Process folder.
    if (node.hasOwnProperty("children"))
    {
        img.src = "img/folder.svg";
        div.addEventListener("click", ntp.parseNodes);
    }
    else
    {
        img.src = "chrome://favicon/size/48/" + node.url;
        anchor.href = node.url;
    }

    label.appendChild(document.createTextNode(title));
    anchor.appendChild(img);
    anchor.appendChild(label);
    div.appendChild(anchor);
    return div;
}

ntp.parseNodes = function(e, pinned, id, up)
{
    id = e ? e.currentTarget.id : id ? id : "1";

    var node = chrome.bookmarks.getSubTree(id,
        function (node)
        {
            var nodes = node[0].children;

            ntp.parentId = node[0].parentId;
            ntp.id = node[0].id;

            var nodeset;

            if (pinned)
            {
                nodeset = document.getElementById("pinned");
            }
            else
            {
                var nav = document.getElementById("navigator");

                if (nav.children.length > 0)
                {
                    nav.children[0].remove();
                }
                
                nodeset = document.createElement("div");
                nav.appendChild(nodeset);

                nodeset.classList += up ? "up" : "down";
            }

            for (var i = 0; i < nodes.length; i++)
            {
                if (nodes[i].id != "282") nodeset.appendChild(ntp.nodeToHtml(nodes[i]));
            }
        }
    );
}

ntp.upHierarchy = function (e)
{
    setTimeout(function(){ntp.ignore = false}, 500);

    if (ntp.ignore == false & ntp.id != ntp.parentId & e.wheelDelta > 0 & ntp.parentId > 0)
    {
        ntp.ignore = true;
        ntp.parseNodes(undefined, false, ntp.parentId, true);
    }
}

ntp.initialize = function ()
{
    ntp.parseNodes(undefined, true, "282");
    ntp.parseNodes();
    document.getElementById("navigator").addEventListener("wheel", ntp.upHierarchy, false);
}

window.onload = ntp.initialize;